function IsUGFNMap(filename)
	return string.match(string.lower(filename), "ugfn") 
end